package example;

class InvalidNameException extends Exception {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InvalidNameException(String message) {
        super(message);
    }

    public static void validateName(String name) throws InvalidNameException {
        if (name.matches(".*[0-9!@#$%^&*()_+\\-=\\[\\]{};':\"\\\\|,.<>\\/?].*")) {
            throw new InvalidNameException("Name should not contain numbers and special symbols.");
        }
    }
}


public class Main {
    public static void main(String[] args) {
        String name = "John Doe 123"; // invalid name with numbers
        try {
            InvalidNameException.validateName(name);
        } catch (InvalidNameException e) {
            System.out.println("Error: " + e.getMessage());
        }

        name = "John-Doe"; // valid name without numbers or special symbols
        try {
            InvalidNameException.validateName(name);
        } catch (InvalidNameException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}

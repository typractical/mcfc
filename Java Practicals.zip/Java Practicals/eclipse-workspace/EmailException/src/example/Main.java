package example;

class InvalidEmailException extends Exception {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InvalidEmailException(String errorMessage) {
        super(errorMessage);
    }

}


public class Main {
    public static void main(String[] args) {
        try {
            String validEmail = "example@email.com";
            checkValidEmail(validEmail);
            System.out.println(validEmail + " is a valid email address");

            String invalidEmail = "invalid_email@domain.invalid";
            checkValidEmail(invalidEmail);
            System.out.println(invalidEmail + " is a valid email address");
        } catch (InvalidEmailException e) {
            System.out.println(e.getMessage());
        }
    }

	public static void checkValidEmail(String email) throws InvalidEmailException {
	    if (!email.matches("^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.(com|co\\.in|org)$")) {
	        throw new InvalidEmailException(email+" is Invalid email address");
	    }
	}
}
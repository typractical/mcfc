abstract class Shape {
    abstract double area();
    abstract double volume();
}

class Cone extends Shape {
    double radius, height;
    
    public Cone(double r, double h) {
        radius = r;
        height = h;
    }
    
    public double area() {
        return Math.PI * radius * (radius + Math.sqrt(radius*radius + height*height));
    }
    
    public double volume() {
        return Math.PI * radius * radius * height / 3.0;
    }
    
    public String toString() {
        return "Cone with radius = " + radius + " and height = " + height;
    }
}

class Cylinder extends Shape {
    double radius, height;
    
    public Cylinder(double r, double h) {
        radius = r;
        height = h;
    }
    
    public double area() {
        return 2 * Math.PI * radius * height + 2 * Math.PI * radius * radius;
    }
    
    public double volume() {
        return Math.PI * radius * radius * height;
    }
    
    public String toString() {
        return "Cylinder with radius = " + radius + " and height = " + height;
    }
}

public class AbstractShape {
    public static void main(String[] args) {
        Shape cone = new Cone(3.0, 4.0);
        System.out.println(cone);
        System.out.println("Area: " + cone.area());
        System.out.println("Volume: " + cone.volume());
        
        System.out.println();
        
        Shape cylinder = new Cylinder(2.0, 5.0);
        System.out.println(cylinder);
        System.out.println("Area: " + cylinder.area());
        System.out.println("Volume: " + cylinder.volume());
    }
}


package trigonometry;

public class Trigonometry {
  public static double sine(double angle) {
    return Math.sin(angle);
  }

  public static double cosine(double angle) {
    return Math.cos(angle);
  }

  public static double tan(double angle) {
    return Math.tan(angle);
  }
}

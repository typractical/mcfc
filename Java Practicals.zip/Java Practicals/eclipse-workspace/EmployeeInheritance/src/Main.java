public class Main {
    public static void main(String[] args) {
        Manager manager = new Manager(1, "John Doe", "Sales", 50000);
        System.out.println(manager);
        manager.calculateSalary();

        SalesManager salesManager = new SalesManager(2, "Jane Smith", "Marketing", 60000, 10000);
        System.out.println(salesManager);
        salesManager.calculateSalary();
    }
}
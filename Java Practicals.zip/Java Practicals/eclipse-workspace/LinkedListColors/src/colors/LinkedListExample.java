
import java.util.LinkedList;
import java.util.ListIterator;

public class LinkedListExample {
    public static void main(String[] args) {
        // Create a linked list of colors
        LinkedList<String> colors = new LinkedList<>();

        // Add four colors to the list
        colors.add("red");
        colors.add("green");
        colors.add("blue");
        colors.add("yellow");

        // Display all colors using an iterator
        ListIterator<String> iterator = colors.listIterator();
        while (iterator.hasNext()) {
            System.out.println(iterator.next());
        }

        // Add two new colors at the beginning of the linked list
        colors.addFirst("orange");
        colors.addFirst("purple");

        // Remove the last color from the list
        colors.removeLast();
        // Display all colors using an iterator
        System.out.println("\nDisplaying colors again");
       iterator = colors.listIterator();
        while (iterator.hasNext()) {
            System.out.println(iterator.next());
        }
    }
}

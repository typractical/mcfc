package example;

import java.util.Vector;

public class VectorExample {
   public static void main(String[] args) {
      Vector<Object> vec = new Vector<Object>();
      
      // Print initial capacity of vector
      System.out.println("Initial capacity of vector: " + vec.capacity());
      
      // Check if vector is empty
      System.out.println("Is vector empty? " + vec.isEmpty());
      
      // Add 4 objects to vector
      vec.add(new Integer(10));
      vec.add(new Float(3.14));
      vec.add(new String("Hello"));
      vec.add(new StringBuffer("world"));
      
      // Display all elements of vector
      System.out.println("Elements in vector: ");
      for (Object obj : vec) {
         System.out.println(obj);
      }
      
      // Delete all elements of vector
      vec.clear();
      System.out.println("Vector after clearing: " + vec);
   }
}

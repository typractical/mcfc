package display;
import trigonometry.Trigonometry;

import java.util.Arrays;

import statistics.Statistics;

public class Display {
  public static void main(String[] args) {
    double angle = Math.PI / 4;
    System.out.println("Sine of " + angle + " is " + Trigonometry.sine(angle));
    System.out.println("Cosine of " + angle + " is " + Trigonometry.cosine(angle));
    System.out.println("Tan of " + angle + " is " + Trigonometry.tan(angle));

    double[] A = { 1.0, 2.0, 3.0, 4.0, 5.0 };
    System.out.println("Mean of " + Arrays.toString(A) + " is " + Statistics.mean(A));
    System.out.println("Median of " + Arrays.toString(A) + " is " + Statistics.median(A));
    System.out.println("Mode of " + Arrays.toString(A) + " is " + Statistics.mode(A));
  }
}

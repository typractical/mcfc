class Account {
    int acno;
    String name;
    double bal;

    // Default constructor
    public Account() {}

    // Parameterized constructor
    public Account(int acno, String name, double bal) {
        this.acno = acno;
        this.name = name;
        this.bal = bal;
    }

    // toString method
    public String toString() {
        return "Account Number: " + acno + "\n" +
               "Name: " + name + "\n" +
               "Balance: " + bal + "\n";
    }

    // Deposit method
    public void deposit(double amount) {
        bal += amount;
    }

    // Withdraw method
    public void withdraw(double amount) {
        bal -= amount;
    }
}

// Savings subclass
class Savings extends Account {
    double min_bal;
    int tran_limit;
    double int_rate;
    int num_transactions;

    // Default constructor
    public Savings() {
        super();
    }

    // Parameterized constructor
    public Savings(int acno, String name, double bal, double min_bal, int tran_limit, double int_rate) {
        super(acno, name, bal);
        this.min_bal = min_bal;
        this.tran_limit = tran_limit;
        this.int_rate = int_rate;
        this.num_transactions = 0;
    }

    // toString method
    public String toString() {
        return super.toString() +
               "Minimum Balance: " + min_bal + "\n" +
               "Transaction Limit: " + tran_limit + "\n" +
               "Interest Rate: " + int_rate + "\n" +
               "Number of Transactions: " + num_transactions + "\n";
    }

    // Withdraw method
    public void withdraw(double amount) {
        if (num_transactions >= tran_limit) {
            System.out.println("Transaction limit reached!");
            return;
        }

        if (bal - amount < min_bal) {
            System.out.println("Minimum balance requirement not met!");
            return;
        }

        super.withdraw(amount);
        num_transactions++;
    }
}

// Current subclass
class Current extends Account {
    double min_bal;

    // Default constructor
    public Current() {
        super();
    }

    // Parameterized constructor
    public Current(int acno, String name, double bal, double min_bal) {
        super(acno, name, bal);
        this.min_bal = min_bal;
    }

    // toString method
    public String toString() {
        return super.toString() +
               "Minimum Balance: " + min_bal + "\n";
    }

    // Withdraw method
    public void withdraw(double amount) {
        if (bal - amount < min_bal) {
            System.out.println("Minimum balance requirement not met!");
            return;
        }

        super.withdraw(amount);
    }
}

// Main class
public class BankAccount {
    public static void main(String[] args) {
        // Creating Savings account object
        Savings savings = new Savings(1234, "John Doe", 10000, 5000, 3, 0.01);
        System.out.println("Savings Account:\n" + savings);

        // Deposit and Withdraw from savings account
        savings.deposit(5000);
        System.out.println("After Deposit:\n" + savings);

        savings.withdraw(2000);
        System.out.println("After Withdrawal:\n" + savings);

        savings.withdraw(2000);
        System.out.println("After Withdrawal:\n" + savings);

        savings.withdraw(2000);
        System.out.println("After Withdrawal:\n" + savings);

        savings.withdraw(2000);
        System.out.println("After Withdrawal:\n" + savings);

        // Creating Current account object
        Current current = new Current(5678, "Jane Smith", 50000, 10000);
        System.out.println("Current Account:\n" + current);

        // Deposit and Withdraw from current account
        current.deposit(10000);
        System.out.println("After Deposit:\n" + current);

        current.withdraw(20000);
        System.out.println("After Withdrawal:\n" + current);

        current.withdraw(40000);
        System.out.println("After Withdrawal:\n" + current);
    }
}

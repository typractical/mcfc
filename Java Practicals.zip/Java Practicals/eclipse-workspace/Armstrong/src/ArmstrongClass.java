
public class ArmstrongClass {

	    public static boolean isArmstrongNumber(int num) {
	        int originalNum = num;
	        int sum = 0;
	        int power = String.valueOf(num).length();
	        
	        while(num > 0) {
	            int digit = num % 10;
	            sum += Math.pow(digit, power);
	            num /= 10;
	        }
	        
	        return (sum == originalNum);
	    }
	    
	    public static void main(String[] args) {
	        int num = 153;
	        if(isArmstrongNumber(num)) {
	            System.out.println(num + " is an Armstrong number.");
	        } else {
	            System.out.println(num + " is not an Armstrong number.");
	        }
	    }
	}


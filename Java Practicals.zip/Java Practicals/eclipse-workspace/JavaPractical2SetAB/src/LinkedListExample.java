
import java.util.LinkedList;

public class LinkedListExample {
    public static void main(String[] args) {
        // Create a linked list of colors
        LinkedList<String> colors = new LinkedList<>();

        // Add four colors to the list
        colors.add("red");
        colors.add("green");
        colors.add("blue");
        colors.add("yellow");

        // Display all colors using an iterator
        for(String i:colors) {
        	System.out.println(i);
        }

        // Add two new colors at the beginning of the linked list
        colors.addFirst("orange");
        colors.addFirst("purple");
        
        System.out.println();
        

        // Remove the last color from the list
        colors.removeLast();
        // Display all colors using an iterator
        for(String i:colors) {
        	System.out.println(i);
        }
    }
}

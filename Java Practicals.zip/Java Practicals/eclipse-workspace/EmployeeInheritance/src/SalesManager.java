public class SalesManager extends Manager {
    private double bonus;

    public SalesManager(int id, String name, String dept, double salary, double bonus) {
        super(id, name, dept, salary);
        this.bonus = bonus;
    }

    public double getBonus() {
        return bonus;
    }

    public void setBonus(double bonus) {
        this.bonus = bonus;
    }

    @Override
    public void calculateSalary() {
        double totalSalary = getSalary() + bonus;
        System.out.println("Salary of Sales Manager " + getName() + " is " + totalSalary);
    }

    @Override
    public String toString() {
        return "SalesManager{" +
                "bonus=" + bonus +
                "} " + super.toString();
    }
}
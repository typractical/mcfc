package polygon;

interface Polygon {
    double area();
}

class Square implements Polygon {
    private double side;

    public Square(double side) {
        this.side = side;
    }

    @Override
    public double area() {
        return side * side;
    }
}

class Rectangle implements Polygon {
    private double length;
    private double width;

    public Rectangle(double length, double width) {
        this.length = length;
        this.width = width;
    }

    @Override
    public double area() {
        return length * width;
    }
}

public class Main {
    public static void main(String[] args) {
        Square square = new Square(5);
        System.out.println("Area of Square: " + square.area());

        Rectangle rectangle = new Rectangle(3, 4);
        System.out.println("Area of Rectangle: " + rectangle.area());
    }
}


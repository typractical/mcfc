package statistics;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

public class Statistics {
  public static double mean(double[] A) {
    double sum = 0.0;
    for (double a : A) {
      sum += a;
    }
    return sum / A.length;
  }

  public static double median(double[] A) {
    Arrays.sort(A);
    if (A.length % 2 == 0) {
      return (A[A.length/2 - 1] + A[A.length/2]) / 2.0;
    } else {
      return A[A.length/2];
    }
  }

  public static double mode(double[] A) {
    Map<Double, Integer> frequency = new HashMap<>();
    for (double a : A) {
      frequency.put(a, frequency.getOrDefault(a, 0) + 1);
    }
    double mode = A[0];
    int maxFrequency = 0;
    for (Map.Entry<Double, Integer> entry : frequency.entrySet()) {
      if (entry.getValue() > maxFrequency) {
        mode = entry.getKey();
        maxFrequency = entry.getValue();
      }
    }
    return mode;
  }
}

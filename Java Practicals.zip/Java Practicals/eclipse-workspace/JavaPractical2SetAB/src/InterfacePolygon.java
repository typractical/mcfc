interface Polygon {
	    double area();
	}
	
	class Square implements Polygon {
	    double side;
	
	    public Square(double side) {
	        this.side = side;
	    }
	
	    @Override
	    public double area() {
	        return side * side;
	    }
	    
	    public String toString() {
		    return "Square:\n"+
		    		"side="+side;
	    }
	}
	
	class Rectangle implements Polygon {
	    double length;
	    double width;
	
	    public Rectangle(double length, double width) {
	        this.length = length;
	        this.width = width;
	    }
	
	    @Override
	    public double area() {
	        return length * width;
	    }
	    
	    public String toString() {
		    return "Rectangle:\n"+
		    		"length="+length+
		    		"\nwidth="+width;
	    }
	}

	public class InterfacePolygon {
	    public static void main(String[] args) {
	        Square square = new Square(5);
	        System.out.println(square);
	        System.out.println("Area of Square: " + square.area());
	        
	        System.out.println();
	
	        Rectangle rectangle = new Rectangle(3, 4);
	        System.out.println(rectangle);
	        System.out.println("Area of Rectangle: " + rectangle.area());
	    }
	}
	

import java.io.*;
public class DataIOStream {
public static void main(String[] args)throws FileNotFoundException,IOException {
FileInputStream in = new FileInputStream(new File("D:\\Data_Folder\\Modern\\Desktop\\Java Practicals\\Text Files\\InFile.txt"));
FileOutputStream out = new FileOutputStream(new File("D:\\Data_Folder\\Modern\\Desktop\\Java Practicals\\Text Files\\OutFile.txt"));
DataInputStream din=null;
DataOutputStream dout = null;
//"D:\Data_Folder\Modern\Desktop\Java Practicals\Text Files\OutFile.txt"
try {
din = new DataInputStream(in);
dout = new DataOutputStream(out);
int c;
while ((c = din.read()) != -1) {
dout.write(c);
}
System.out.println("Successfully done");
} catch(Exception e){
e.printStackTrace();
}
finally {
}
if (din != null) {
din.close();
}
if (dout != null) {
dout.close();
}
}
}
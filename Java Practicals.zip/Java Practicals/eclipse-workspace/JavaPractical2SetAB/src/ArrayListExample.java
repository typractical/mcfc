import java.util.*;

public class ArrayListExample {

    public static void main(String[] args) {

        // Create an ArrayList of Days
        ArrayList<String> daysList = new ArrayList<String>();

        // Add 7 days to the list
        daysList.add("Sun");
        daysList.add("Mon");
        daysList.add("Tue");
        daysList.add("Wed");
        daysList.add("Thu");
        daysList.add("Fri");
        daysList.add("Sat");
        

        // Display the size of the list
        System.out.println("Size of the list: " + daysList.size());

        // Print all days using an iterator
        System.out.println("All days in the list:");
        for(String i:daysList) {
        	System.out.println(i);
        }

        // Check if "Wed" is present in the ArrayList
        if (daysList.contains("Wed")) {
            System.out.println("The list contains Wed.");
        } else {
            System.out.println("The list does not contain Wed.");
        }
        

        // Delete 3rd and 5th day
        daysList.remove(2); // 3rd day is at index 2
        daysList.remove(3); // 5th day is now at index 3

        // Print all days again
        System.out.println("All days in the list after removing 3rd and 5th day:");
        for(String i:daysList) {
        	System.out.println(i);
        }
    }
}


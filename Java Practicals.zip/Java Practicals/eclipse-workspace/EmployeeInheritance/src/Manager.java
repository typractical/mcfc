
public class Manager extends Employee {
    private String dept;
    private double salary;

    public Manager(int id, String name, String dept, double salary) {
        super(id, name);
        this.dept = dept;
        this.salary = salary;
    }

    public String getDept() {
        return dept;
    }

    public void setDept(String dept) {
        this.dept = dept;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    public void calculateSalary() {
        System.out.println("Salary of Manager " + getName() + " is " + salary);
    }

    @Override
    public String toString() {
        return "Manager{" +
                "dept='" + dept + '\'' +
                ", salary=" + salary +
                "} " + super.toString();
    }
}
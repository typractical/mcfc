package example;

import java.util.Hashtable;

public class StudentHashtable {

    public static void main(String[] args) {
        
        // Create a new Hashtable
        Hashtable<Integer, String> student = new Hashtable<>();
        
        // Add records of 5 students to it
        student.put(1, "Alice");
        student.put(2, "Bob");
        student.put(3, "Charlie");
        student.put(4, "John");
        student.put(5, "Emily");
        
        // Display the elements of the Hashtable
        System.out.println("Hashtable before removing John: " + student);
        
        // Remove student with name "John"
        student.values().removeIf(name -> name.equals("John"));
        
        // Display the elements of the Hashtable again
        System.out.println("Hashtable after removing John: " + student);
    }
}

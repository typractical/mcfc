import java.util.Scanner;

public class MultiplyClass {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        // Read the dimensions of matrices A and B from the user
        System.out.print("Enter the number of rows of matrix A: ");
        int rowsA = sc.nextInt();
        System.out.print("Enter the number of columns of matrix A: ");
        int colsA = sc.nextInt();
        System.out.print("Enter the number of rows of matrix B: ");
        int rowsB = sc.nextInt();
        System.out.print("Enter the number of columns of matrix B: ");
        int colsB = sc.nextInt();

        // Check if matrix multiplication is possible
        if (colsA != rowsB) {
            System.out.println("Matrix multiplication is not possible.");
            System.exit(0);
        }

        // Declare matrices A, B, and C
        int[][] A = new int[rowsA][colsA];
        int[][] B = new int[rowsB][colsB];
        int[][] C = new int[rowsA][colsB];

        // Read matrix A from the user
        System.out.println("Enter the elements of matrix A:");
        for (int i = 0; i < rowsA; i++) {
            for (int j = 0; j < colsA; j++) {
                A[i][j] = sc.nextInt();
            }
        }

        // Read matrix B from the user
        System.out.println("Enter the elements of matrix B:");
        for (int i = 0; i < rowsB; i++) {
            for (int j = 0; j < colsB; j++) {
                B[i][j] = sc.nextInt();
            }
        }

        // Perform matrix multiplication and store the result in matrix C
        for (int i = 0; i < rowsA; i++) {
            for (int j = 0; j < colsB; j++) {
                for (int k = 0; k < colsA; k++) {
                    C[i][j] += A[i][k] * B[k][j];
                }
            }
        }

        // Print the result matrix C
        System.out.println("Result matrix C:");
        for (int i = 0; i < rowsA; i++) {
            for (int j = 0; j < colsB; j++) {
                System.out.print(C[i][j] + " ");
            }
            System.out.println();
        }

        sc.close();
    }
}

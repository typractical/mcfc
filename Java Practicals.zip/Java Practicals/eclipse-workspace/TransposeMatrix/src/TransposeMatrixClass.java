
public class TransposeMatrixClass {
			   public static void main(String[] args) {
			      int[][] matrix = { {1, 2, 3, 4, 5, 6},
			                         {7, 8, 9, 10, 11, 12},
			                         {13, 14, 15, 16, 17, 18},
			                         {19, 20, 21, 22, 23, 24} };
			      
			      System.out.println("Original Matrix:");
			      displayMatrix(matrix);
			      
			      int[][] transpose = transposeMatrix(matrix);
			      
			      System.out.println("\nTransposed Matrix:");
			      displayMatrix(transpose);
			   }
			   
			   // function to transpose a matrix
			   public static int[][] transposeMatrix(int[][] matrix) {
			      int rows = matrix.length;
			      int cols = matrix[0].length;
			      int[][] transpose = new int[cols][rows];
			      
			      for(int i=0; i<rows; i++) {
			         for(int j=0; j<cols; j++) {
			            transpose[j][i] = matrix[i][j];
			         }
			      }
			      
			      return transpose;
			   }
			   
			   // function to display a matrix
			   public static void displayMatrix(int[][] matrix) {
			      int rows = matrix.length;
			      int cols = matrix[0].length;
			      
			      for(int i=0; i<rows; i++) {
			         for(int j=0; j<cols; j++) {
			            System.out.print(matrix[i][j] + " ");
			         }
			         System.out.println();
			      }
			   }
			}
